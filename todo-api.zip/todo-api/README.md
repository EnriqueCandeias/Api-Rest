# Todo List API

Cette API RESTful permet de gérer une liste de tâches (Todo List). Elle propose des fonctionnalités pour créer, lire, mettre à jour et supprimer des tâches.


1. Clonez le projet :
   git clone https://github.com/votre-utilisateur/todo-list-api.git


2. Accédez au répertoire :
    cd todo-list-api

3. Accédez au répertoire :
    npm install

4. Démarrage :
Démarrez le serveur en exécutant :
    npm start
